# Edit the credit text here.
define credits_creator = "Glory Kellogg"

screen credits(after_ending=False):
    modal True
    zorder 150
    add Solid("#f5efdf")
    vbox:
        xalign 0.5
        ypos (20 if renpy.variant("touch") else 36)
        spacing (8 if renpy.variant("touch") else 18)
        text "Credits" size touch_size(40, 1.2) color "#292929" xalign 0.5
        text "Lost in the Stacks" size touch_size(25, 1.2) color "#483248" xalign 0.5
        vbox:
            xalign 0.5
            spacing 4
            text "Game design, writing & original drawings" size touch_size(19, 1.2) color "#555555" xalign 0.5
            text credits_creator size touch_size(25, 1.2) color "#292929" xalign 0.5
        vbox:
            xalign 0.5
            spacing 4
            text "Music" size touch_size(19, 1.2) color "#555555" xalign 0.5
            text "The Rite of Spring — Part One: The Fertility of the Earth" size touch_size(22, 1.2) color "#292929" xalign 0.5
            text "Igor Stravinsky · Boston Symphony Orchestra" size touch_size(20, 1.2) color "#292929" xalign 0.5
            text "Pierre Monteux, conductor · 1951 recording" size touch_size(20, 1.2) color "#292929" xalign 0.5
            text "LP transfer by Bob Varney · Internet Archive" size touch_size(18, 1.2) color "#555555" xalign 0.5
        vbox:
            xalign 0.5
            spacing 4
            text "Made with Ren’Py" size touch_size(22, 1.2) color "#292929" xalign 0.5
            text "Latin Modern Roman · GUST Font License" size touch_size(19, 1.2) color "#555555" xalign 0.5
            text "Coding, dialogue development & additional artwork assistance" size touch_size(19, 1.2) color "#555555" xalign 0.5
            text "OpenAI ChatGPT / Codex and image generation" size touch_size(19, 1.2) color "#292929" xalign 0.5
        text "Created for Game Design I" size touch_size(19, 1.2) color "#555555" xalign 0.5
        textbutton ("Continue" if after_ending else "Back"):
            xalign 0.5
            text_size touch_size(23, 1.2)
            action (Return() if after_ending else Hide("credits"))
    key "game_menu" action (Return() if after_ending else Hide("credits"))
    if after_ending:
        key "K_RETURN" action Return()
        key "K_KP_ENTER" action Return()

Soundtrack: rite-of-spring-part-one.mp3
User-provided Part One: The Fertility of the Earth, from The Rite of Spring.
Starts at 2:30 with a three-second fade-in and loops back to 2:30.
Loops continuously on the title, dialogue, timed game, wrong turns, and endings.
Source: https://archive.org/details/the-rite-of-spring_202305

Optional sound effects (silent when absent):
flutter.ogg      correct corridor
wrong_turn.ogg   wrong corridor or shelf gap
success.ogg      successful shelving
closing_bell.ogg timeout

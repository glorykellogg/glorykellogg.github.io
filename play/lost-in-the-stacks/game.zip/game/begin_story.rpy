# Untimed page between the introduction and the library race.
screen begin_story():
    modal True
    add Solid("#f5efdf")
    add "images/begin_story_open_book-cutout.png":
        xalign 0.5
        ypos 20
        xysize (930, 620)
        fit "contain"
        alt "An open book reading: Begin your story..."
    text "Press Enter to start the clock":
        xalign 0.5
        ypos 655
        size 18
        color "#555555"
    key "K_RETURN" action Return()
    key "K_KP_ENTER" action Return()
    key "game_menu" action NullAction()
    textbutton "Back":
        xpos 40
        ypos 650
        background None
        hover_background Solid("#e4ddc9")
        text_color "#555555"
        text_insensitive_color "#aaa594"
        text_size 18
        action Rollback()

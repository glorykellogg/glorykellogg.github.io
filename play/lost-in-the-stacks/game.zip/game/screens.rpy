# A deliberately small custom UI: no dependency on a generated Ren'Py template.
init 1:
    style default:
        font game_serif
        size touch_size(22)
        color "#f1ead9"
    style button:
        background Solid("#292929")
        hover_background Solid("#454545")
        insensitive_background Solid("#333333")
        padding (18, 13)
    style button_text:
        color "#f1ead9"
        hover_color "#ffda98"
        size touch_size(21)
    style frame:
        background Solid("#172825ee")
        padding (24, 22)

screen say(who, what):
    $ shelf_narration = renpy.showing("book shelved")
    window:
        id "window"
        background Solid("#483248" if who == "Nico Weaver" else "#254117" if who == "Mrs. Watson" else "#292929")
        xfill True
        yalign 1.0
        ysize ((250 if who else (230 if shelf_narration else 280)) if renpy.variant("touch") else (126 if shelf_narration else 214))
        padding ((40, 14) if shelf_narration else (70, 25))
        vbox:
            spacing 14
            if who:
                text who id "who" size touch_size(24) bold False font "fonts/lmroman10-bold.otf" color "#ffffff"
            text what id "what" size touch_size(20 if shelf_narration else 24) color "#ffffff" xmaximum (1200 if shelf_narration else 1130)
    textbutton "Back":
        id "dialogue_back"
        xpos 40
        ypos (652 if renpy.variant("touch") else 671)
        padding ((22, 12) if renpy.variant("touch") else (16, 5))
        text_size touch_size(17)
        text_insensitive_color "#718078"
        action Rollback()
    text ("Tap to continue" if renpy.variant("touch") else "Click / Enter to continue") size touch_size(15) color "#ffffff" xpos (1000 if renpy.variant("touch") else 990) ypos (672 if renpy.variant("touch") else 690)

screen choice(items):
    modal True
    frame:
        xalign 0.5
        yalign 0.55
        vbox:
            spacing 12
            for item in items:
                textbutton item.caption action item.action xminimum 500

screen main_menu():
    tag menu
    use title_card

screen instructions(from_settings=False):
    modal True
    zorder 100
    add Solid("#081513ed")
    frame:
        xalign 0.5
        yalign 0.5
        xsize (1140 if renpy.variant("touch") else 820)
        vbox:
            spacing (12 if renpy.variant("touch") else 19)
            text "Your assignment" size touch_size(36) color "#e6bf79"
            text "Return The Lives of Butterflies (595.789). Choose progressively narrower Dewey sections, then insert the book in ascending numerical order."
            text "The clock starts at 5:59 PM after the introduction. The library closes at six. Wrong corridors cost 20 seconds; misplaced books cost 15; butterfly-blocked clicks cost 5."
            text "Follow the Dewey numbers to return the book numbered 595.789."
            text "Tap or click choices and shelf gaps. Tap dialogue to continue. Use Start the clock to begin and Pause to take a break. Keyboard controls also work. Back rereads dialogue; timed decisions cannot be undone."
            textbutton "Back" action (Function(return_to_web_settings, "instructions") if from_settings else Hide("instructions"))
    key "game_menu" action (Function(return_to_web_settings, "instructions") if from_settings else Hide("instructions"))

screen expedition():
    timer 0.1 repeat True action Function(tick_clock)
    key "game_menu" action Function(pause_shift)
    if patron_phase:
        use patron_encounter
    elif wrong_shelf:
        use wrong_shelf_scene
    elif wrong_turn:
        use wrong_turn_scene
    elif stage < len(STAGES):
        use first_hallway
    else:
        use shelf_puzzle
    use carried_book

screen shelf_puzzle():
    add "bg butterfly_shelf"
    use shelf_numbers

    for i, gap_x in enumerate((235, 515, 770, 1040)):
        button:
            id ("shelf_gap_%d" % i)
            xpos gap_x
            xanchor 0.5
            ypos 295
            xsize (88 if renpy.variant("touch") else 64)
            padding (2, 6)
            ysize 215
            background Solid("#00000000")
            hover_background Solid("#e6bf7940")
            action Function(choose_path, i)
            alt SHELF_OPTIONS[i]
            text "Place here":
                xalign 0.5
                yalign 1.0
                size touch_size(16)
                color "#292929"

    # Staggered circuits and stable identities prevent overlapping/resetting sprites.
    for i in range(14):
        # A generous footprint stays solid even while the wings fold.
        button at shelf_butterfly_flight(i):
            id ("shelf_butterfly_%d" % i)
            xysize (160, 142)
            background None
            hover_background None
            padding (0, 0)
            focus_mask None
            keyboard_focus False
            action Function(butterfly_blocked)
            alt "A butterfly is blocking this part of the shelf."
            add Transform("butterfly", xysize=(120, 102), fit="contain") at shelf_wingbeat(i)

    use library_clock


screen pause_menu():
    modal True
    zorder 100
    add Solid("#081513ed")
    frame:
        xalign 0.5
        yalign 0.5
        xsize 550
        vbox:
            spacing 20
            text "Between the pages" size touch_size(36) color "#e6bf79"
            text "The clock is paused."
            textbutton "Resume shift" action Function(resume_shift) xfill True
            textbutton "Instructions" action Show("instructions") xfill True
            textbutton "Restart shift" action [Hide("pause_menu"), SetVariable("clock_running", False), Jump("start")] xfill True
            textbutton "Return to title" action [Hide("pause_menu"), SetVariable("clock_running", False), MainMenu(confirm=False)] xfill True
    key "game_menu" action Function(resume_shift)

screen ending_card(won, fired=False):
    modal True
    add Solid("#f5efdf")
    vbox:
        xalign 0.5
        yalign 0.5
        spacing 30
        text ("This chapter is closed." if fired else "Right where it belongs" if won else "Closed for the night"):
            font game_serif
            size touch_size(42)
            color "#292929"
            xalign 0.5
        add "butterfly":
            xalign 0.5
            xysize (74, 64)
            fit "contain"
        text ("Dismissed by Mrs. Watson" if fired else "%s left · %d mistakes" % (clock_text(remaining), mistakes) if won else "%d mistakes · Time ran out" % mistakes):
            size touch_size(20)
            color "#555555"
            xalign 0.5
        textbutton "Try another shift":
            xalign 0.5
            text_size touch_size(20)
            action Jump("another_shift")
        textbutton "Credits":
            xalign 0.5
            text_size touch_size(20)
            action Show("credits")

screen confirm(message, yes_action, no_action):
    modal True
    zorder 200
    add Solid("#081513ee")
    frame:
        xalign 0.5
        yalign 0.5
        vbox:
            spacing 20
            text message
            textbutton "Yes" action yes_action
            textbutton "No" action no_action

screen notify(message):
    zorder 200
    frame:
        xalign 0.5
        ypos 20
        text message
    timer 3.0 action Hide("notify")

# Opening timed junctions: labels come from route data, not the artwork.
screen first_hallway():
    key "K_LEFT" action Function(choose_path, 0)
    $ three_routes = (len(route_stages[stage]["options"]) == 3)
    key "K_RIGHT" action Function(choose_path, 2 if three_routes else 1)
    if three_routes:
        key "K_UP" action Function(choose_path, 1)
        add "bg three_way_hallway"
    else:
        add "bg two_way_hallway"
    add "nico running_back" at nico_running_motion
    use nico_butterflies
    use library_clock

    for i, option in enumerate(route_stages[stage]["options"]):
        $ dewey_range, subject = option.partition(" · ")[::2]
        button:
            id ("hallway_sign_%d" % i)
            xpos (((50, 510, 970)[i] if three_routes else (50, 970)[i]) if renpy.variant("touch") else ((70, 530, 990)[i] if three_routes else (70, 990)[i]))
            ypos 215
            xsize (260 if renpy.variant("touch") else 220)
            ysize (82 if renpy.variant("touch") else 56)
            background Solid("#292929")
            hover_background Solid("#48443c")
            padding (12, 9)
            action Function(choose_path, i)
            vbox:
                xalign 0.5
                yalign 0.5
                spacing 3
                text (("← " + dewey_range) if i == 0 else (("↑ " + dewey_range) if three_routes and i == 1 else (dewey_range + " →"))) size touch_size(25) color "#f5efdf" xalign 0.5

screen wrong_turn_scene():
    add "bg wrong_turn"
    add "nico running_back" at nico_running_motion
    use nico_butterflies
    key "K_RETURN" action Function(return_from_wrong_turn)
    key "K_KP_ENTER" action Function(return_from_wrong_turn)
    use library_clock
    frame:
        xalign 0.5
        yalign 1.0
        yoffset -16
        xsize (1120 if renpy.variant("touch") else 850)
        padding (18, 14)
        background Solid("#292929")
        vbox:
            spacing 8
            text "The same open book. The same torn page. You have passed this shelf before." size touch_size(20) color "#ffffff"
            textbutton "Turn back":
                id "turn_back"
                action Function(return_from_wrong_turn)
                text_size touch_size(22)
                padding (22, 12)

screen shelf_numbers():
    zorder 0
    use shelf_fillers
    # Labels sit inside the three blank spine labels in the artwork.
    for number, spine_x in (("595.78", 392), ("595.788", 641), ("595.79", 902)):
        text number:
            xpos spine_x
            ypos 451
            anchor (0.5, 0.5)
            size touch_size(14)
            color "#292929"


# Fill the intervals between the four 64-pixel slots and the three numbered books.
screen shelf_fillers():
    for left, right, count in ((86,203,2), (267,351,1), (440,483,1), (547,596,1), (686,738,1), (802,854,1), (945,1008,1), (1072,1195,2)):
        for j in range(count):
            add "shelf filler":
                xpos int(left + j * (right-left) / float(count))
                ypos 236
                xysize (int((right-left) / float(count) + 0.5), 295)
                fit "fill"

screen patron_encounter():
    add "bg three_way_hallway"
    add "patron waiting":
        xpos 115
        ypos 75
    use library_clock
    frame:
        xpos (430 if renpy.variant("touch") else 590)
        ypos (150 if renpy.variant("touch") else 230)
        xsize (800 if renpy.variant("touch") else 640)
        padding (24, 20)
        background Solid("#ffffff")
        vbox:
            spacing 12
            if patron_phase == 1:
                text "Excuse me. Do you have the new Dan Brown? I can't remember the title. There's a symbol on the cover. Or perhaps a door." size touch_size(23) color "#292929"
                textbutton "Mrs. Watson at the front desk would be happy to help." action Function(answer_patron, 0) style "nico_reply" text_size touch_size(18, 1.5) xfill True
                textbutton "A professor, a secret society, and a ridiculous twist? That narrows it down to every Dan Brown book." action Function(answer_patron, 2) style "nico_reply" text_size touch_size(18, 1.5) xfill True
            else:
                text patron_reply size touch_size(22) color "#292929"
                if patron_phase == 2:
                    textbutton "She knows the catalogue better than anyone. Just ask her." action Function(continue_patron, 0) style "nico_reply" text_size touch_size(18, 1.5) xfill True
                    textbutton "Try listening. The front desk. Over there." action Function(continue_patron, 2) style "nico_reply" text_size touch_size(18, 1.5) xfill True
                elif patron_phase == 3:
                    textbutton "Thank you for understanding. I hope you find it." action Function(leave_patron, 0) style "nico_reply" text_size touch_size(18, 1.5) xfill True
                    textbutton "Finally. Some of us have actual work to do." action Function(leave_patron, 2) style "nico_reply" text_size touch_size(18, 1.5) xfill True
                else:
                    if not paused:
                        timer 2.0 action Function(finish_patron)

screen nico_butterflies():
    for i in range(3):
        add "butterfly" at flutter(i * 0.08), butterfly_around_nico(i * 2.0944, 0.85 + i * 0.12):
            xysize (34, 29)
            fit "contain"

# A misfiled book earns a personal correction before the player retries.
screen wrong_shelf_scene():
    add "bg butterfly_shelf"
    use shelf_numbers
    add "watson closeup" at watson_closeup_position
    key "K_RETURN" action Function(retry_shelf)
    key "K_KP_ENTER" action Function(retry_shelf)
    use library_clock
    frame:
        xalign 0.5
        yalign 1.0
        xfill True
        padding (40, 20)
        background Solid("#254117")
        vbox:
            spacing 10
            text "Mrs. Watson" size touch_size(18) bold False font "fonts/lmroman10-bold.otf" color "#ffffff"
            text "Nico. The numbers are not decorative. Read every digit, then put it where it belongs." size touch_size(23) color "#ffffff"
            textbutton "Try again" action Function(retry_shelf) text_size touch_size(22) padding (22, 12)

# Shared compact clock for every timed scene.
screen library_clock():
    frame:
        xanchor 1.0
        xpos 1262
        ypos 18
        xsize 196
        padding (2, 2)
        background Solid("#b8af98")
        frame:
            xfill True
            padding (14, 10)
            background Solid("#292929")
            vbox:
                xfill True
                spacing 5
                text library_clock_text(remaining):
                    xalign 0.5
                    font game_serif
                    size touch_size(28)
                    color ("#eaa899" if remaining <= 30 else "#f5efdf")
                textbutton "Pause":
                    xalign 0.5
                    background None
                    hover_background Solid("#45433e")
                    padding ((20, 12) if renpy.variant("touch") else (14, 3))
                    text_size (28 if renpy.variant("touch") else 12)
                    text_color "#e6bf79"
                    action Function(pause_shift)

style nico_reply is button:
    background Solid("#483248")
    hover_background Solid("#604560")

style nico_reply_text is button_text:
    color "#ffffff"
    hover_color "#ffffff"

# A persistent call-number reference, visible only during the timed expedition.
screen carried_book():
    fixed:
        xpos 18
        ypos 18
        xsize 100
        ysize 146
        add "images/lives_of_butterflies.png":
            xalign 0.5
            xysize (90, 110)
            fit "contain"
            alt "The Lives of Butterflies, call number 595.789"
        frame:
            ypos 114
            xalign 0.5
            background Solid("#ffffff")
            padding (7, 3)
            text "595.789" size touch_size(21) color "#292929"

screen butterfly_obstruction():
    zorder 10
    if clock_running and not paused and stage == len(STAGES) and not wrong_shelf:
        frame:
            xalign 0.5
            yalign 1.0
            yoffset -16
            xsize (800 if renpy.variant("touch") else 580)
            padding (20, 12)
            background Solid("#483248")
            vbox:
                spacing 5
                text "Nico Weaver" font "fonts/lmroman10-bold.otf" size touch_size(18) color "#ffffff"
                text "Ah! These butterflies are in my way!" size touch_size(23) color "#ffffff"
    timer 2.0 action Hide("butterfly_obstruction")

# The browser menu uses the game's music mixer and clock, not a separate timer.
init python:
    def open_web_settings():
        if not store.web_settings_open:
            tick_clock()
            store.web_settings_was_paused = store.paused
            store.web_settings_open = True
            store.paused = True
            renpy.restart_interaction()
        return preferences.get_mute("music")

    def close_web_settings():
        if store.web_settings_open:
            store.last_tick = time.monotonic()
            store.paused = store.web_settings_was_paused
            store.web_settings_open = False
            renpy.restart_interaction()

    def return_to_web_settings(page):
        renpy.hide_screen(page)
        if renpy.emscripten:
            import emscripten
            emscripten.run_script("window.stacksReturnToSettings()")
        renpy.restart_interaction()

    def toggle_web_music():
        preferences.set_mute("music", not preferences.get_mute("music"))
        renpy.save_persistent()
        return preferences.get_mute("music")

default web_settings_open = False
default web_settings_was_paused = False

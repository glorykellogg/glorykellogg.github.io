init python:
    import time
    from stacks_rules import TIME_LIMIT, WRONG_TURN_COST, WRONG_SHELF_COST, BUTTERFLY_BLOCK_COST
    from stacks_rules import STAGES, SHELF_OPTIONS, CORRECT_SLOT, spend_time, clock_text, library_clock_text, shuffled_stages

    def optional_audio(filename, channel="sound", loop=False):
        # Silent until the corresponding user-supplied file exists.
        if renpy.loadable(filename):
            renpy.music.play(filename, channel=channel, loop=loop)

    def start_shift():
        renpy.hide_screen("butterfly_obstruction")
        # Prepare the complete shelf and ending artwork during corridor play.
        renpy.start_predict("bg butterfly_shelf", "shelf filler", "book shelved",
                            "bg library_desk", "watson closeup", "nico closeup",
                            "nico at_desk", "watson behind_desk", "desk foreground")
        renpy.start_predict_screen("shelf_puzzle")
        renpy.start_predict_screen("wrong_shelf_scene")
        store.route_stages = shuffled_stages(renpy.random)
        store.butterfly_flight_time = 0.0
        store.remaining = TIME_LIMIT
        store.stage = 0
        store.wrong_turn = False
        store.wrong_shelf = False
        store.patron_seen = False
        store.patron_phase = 0
        store.patron_rude_replies = 0
        store.patron_reply = ""
        store.mistakes = 0
        store.feedback = "Find the right shelf before the library closes."
        store.paused = False
        store.clock_running = True
        store.last_tick = time.monotonic()
        # Keep the title/intro soundtrack playing through the timed section.

    def tick_clock():
        now = time.monotonic()
        elapsed = now - store.last_tick
        store.last_tick = now
        if store.clock_running and not store.paused:
            store.butterfly_flight_time += elapsed
            store.remaining = spend_time(store.remaining, elapsed)
            if store.remaining <= 0:
                store.clock_running = False
                renpy.jump("timeout_ending")

    def choose_path(index):
        # Check elapsed time before accepting a last-second answer.
        tick_clock()
        if not store.clock_running or store.paused or store.wrong_turn or store.wrong_shelf or store.patron_phase:
            return
        if store.stage < len(STAGES):
            node = store.route_stages[store.stage]
            if index == node["correct"]:
                store.stage += 1
                if store.stage == 3 and not store.patron_seen:
                    store.patron_seen = True
                    store.patron_phase = 1
                store.feedback = "You must be getting closer. The book stirs in your hands."
                optional_audio("audio/flutter.ogg")
            else:
                store.wrong_turn = True
                store.mistakes += 1
                store.remaining = spend_time(store.remaining, WRONG_TURN_COST)
                store.feedback = "Dead end! −20 seconds getting back. " + node["hint"]
                optional_audio("audio/wrong_turn.ogg")
        elif index == CORRECT_SLOT:
            store.clock_running = False
            renpy.jump("success_ending")
        else:
            store.mistakes += 1
            store.wrong_shelf = True
            store.remaining = spend_time(store.remaining, WRONG_SHELF_COST)
            store.feedback = "Wrong gap! −15 seconds. Compare 595.788, 595.789, then 595.790 (595.79)."
            optional_audio("audio/wrong_turn.ogg")
        if store.remaining <= 0:
            store.clock_running = False
            renpy.jump("timeout_ending")
        renpy.restart_interaction()

    def patron_time_cost(tone):
        store.remaining = spend_time(store.remaining, (3, 8, 15)[tone])
        if tone == 2:
            store.mistakes += 1
            store.patron_rude_replies += 1
        if store.patron_rude_replies == 3:
            store.clock_running = False
            store.patron_phase = 0
            renpy.jump("fired_ending")
        if store.remaining <= 0:
            store.clock_running = False
            renpy.jump("timeout_ending")

    def answer_patron(tone):
        tick_clock()
        if not store.clock_running or store.paused or store.patron_phase != 1:
            return
        patron_time_cost(tone)
        store.patron_reply = (
            "Thank you. Mrs. Watson, was it? I do hate bothering people. Does she mind questions?",
            "The desk. Right. I did look there, but she seemed busy. I only need a little help.",
            "I happen to enjoy his books. I came here for a recommendation, not a review of my taste. Could you at least tell me who will help?",
        )[tone]
        store.patron_phase = 2
        renpy.restart_interaction()

    def continue_patron(choice=0):
        tick_clock()
        if not store.clock_running or store.paused or store.patron_phase != 2:
            return
        patron_time_cost(choice)
        store.patron_reply = (
            "All right. Thank you for explaining. I will ask her and let you get on.",
            "Fine. I will try again. You could sound a little less eager to be rid of me.",
            "There is no need to speak to me like that. I will be asking Mrs. Watson about more than Dan Brown now.",
        )[choice]
        store.patron_phase = 3
        renpy.restart_interaction()

    def leave_patron(tone=0):
        tick_clock()
        if not store.clock_running or store.paused or store.patron_phase != 3:
            return
        patron_time_cost(tone)
        store.patron_reply = (
            "Thank you. Good luck with your book—and those butterflies.",
            "Yes, yes. I am going. No need to usher me out.",
            "Charming. I will remember that. And your name.",
        )[tone]
        store.patron_phase = 4
        renpy.restart_interaction()

    def finish_patron():
        if store.clock_running and not store.paused and store.patron_phase == 4:
            store.patron_phase = 0
            renpy.restart_interaction()

    def butterfly_blocked():
        tick_clock()
        if not store.clock_running or store.paused or store.wrong_shelf or store.stage != len(STAGES):
            return
        store.mistakes += 1
        store.remaining = spend_time(store.remaining, BUTTERFLY_BLOCK_COST)
        if store.remaining <= 0:
            store.clock_running = False
            renpy.jump("timeout_ending")
        # Repeated clicks keep one short message visible, without stacking boxes.
        renpy.hide_screen("butterfly_obstruction")
        renpy.show_screen("butterfly_obstruction")
        renpy.restart_interaction()

    def retry_shelf():
        tick_clock()
        if not store.clock_running or store.paused:
            return
        store.wrong_shelf = False
        renpy.restart_interaction()

    def return_from_wrong_turn():
        tick_clock()
        if not store.clock_running or store.paused:
            return
        store.wrong_turn = False
        renpy.restart_interaction()

    def pause_shift():
        tick_clock()
        store.paused = True
        renpy.show_screen("pause_menu")

    def resume_shift():
        store.last_tick = time.monotonic()
        store.paused = False
        renpy.hide_screen("pause_menu")

default remaining = 60.0
default stage = 0
default mistakes = 0
default feedback = ""
default paused = False
default clock_running = False
default last_tick = 0.0


default wrong_turn = False

default patron_seen = False
default patron_phase = 0
default patron_reply = ""

default patron_followup = ""

default wrong_shelf = False

default route_stages = list(STAGES)

default butterfly_flight_time = 0.0

default patron_rude_replies = 0

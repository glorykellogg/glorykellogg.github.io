define n = Character("Nico Weaver", who_color="#ffffff", who_font="fonts/lmroman10-bold.otf", who_bold=False)
define w = Character("Mrs. Watson", who_color="#ffffff", who_font="fonts/lmroman10-bold.otf", who_bold=False)

label start:
    $ _rollback = True
    $ renpy.block_rollback()
    $ renpy.music.play("<from 150 loop 150>audio/rite-of-spring-part-one.mp3", loop=True, if_changed=True, fadein=3.0)
    $ clock_running = False
    $ paused = False
    call library_desk_scene
    w "Nico. One book left. We close at six. I expect both of you to be where you belong."
    scene bg book_closeup
    show book lives at book_closeup_position
    n "The Lives of Butterflies. Mrs. Watson... the cover is moving."
    scene bg library_desk
    show watson closeup at watson_closeup_position
    w "Then shelve it before it gets ideas. 595.789. Follow the numbers."
    scene bg library_desk
    show nico closeup at nico_closeup_position
    n "And if the corridors have moved again?"
    call library_desk_scene
    w "Then it's fortunate we've put numbers on everything. Read them."
    w "Smallest to largest on the shelf. Every decimal place counts. Almost right is still wrong."
    scene bg library_desk
    show nico closeup at nico_closeup_position
    n "Okay, focus on paying rent, Nico. The mysterious fluttering book can wait."
    "Wrong turns cost twenty seconds. Misfiled books cost fifteen. Clicking a butterfly costs five. A conversation can cost more than you think."
    "One minute until closing. Arrow keys or click to choose a corridor. Escape to pause."
    jump begin_shift

label another_shift:
    $ clock_running = False
    $ paused = False
    $ _rollback = False
    $ renpy.block_rollback()
    $ renpy.music.play("<from 150 loop 150>audio/rite-of-spring-part-one.mp3", loop=True, if_changed=True, fadein=3.0)
    jump begin_shift

label begin_shift:
    window hide
    call screen begin_story
    $ _rollback = False
    $ renpy.block_rollback()
    scene bg library
    $ start_shift()
    call screen expedition
    return

# Ending layers are staged together before dialogue starts; use immediate cuts
# so screen-layer shelf details and master-layer artwork appear in the same frame.
label success_ending:
    stop music fadeout 3.0
    $ _rollback = True
    $ renpy.block_rollback()
    $ clock_running = False
    $ paused = False
    hide screen expedition
    hide screen pause_menu
    scene bg butterfly_shelf
    show book shelved at shelved_book_position
    show screen shelf_numbers
    $ optional_audio("audio/success.ogg")
    "The book slips into place. One by one, the butterflies settle between its pages. Finally, stillness settles over the library as the clock chimes six."
    hide screen shelf_numbers
    scene bg library_desk
    show watson closeup at watson_closeup_position
    w "Correctly shelved. Before closing, too."
    scene bg library_desk
    show nico closeup at nico_closeup_position
    n "Was that a compliment?"
    scene bg library_desk
    show watson closeup at watson_closeup_position
    w "Don't misfile it."
    window hide
    call screen ending_card(True)
    return

label timeout_ending:
    $ _rollback = True
    $ renpy.block_rollback()
    $ clock_running = False
    $ paused = False
    $ remaining = 0.0
    hide screen expedition
    hide screen pause_menu
    call library_desk_scene
    $ optional_audio("audio/closing_bell.ogg")
    "The closing bell rings. Every butterfly vanishes. The book is still in your hands."
    scene bg library_desk
    show watson closeup at watson_closeup_position
    w "The clock has done its job, Nico. A pity you haven’t."
    scene bg library_desk
    show nico closeup at nico_closeup_position
    n "Tomorrow, I'm following the numbers."
    window hide
    call screen ending_card(False)
    return

# Shared staging for the introduction and both conversations at the desk.
label library_desk_scene:
    scene bg library_desk
    show nico at_desk at nico_at_desk zorder 10
    show watson behind_desk at watson_at_desk zorder 10
    show desk foreground at desk_in_front zorder 20
    return

label fired_ending:
    $ clock_running = False
    $ paused = False
    $ _rollback = True
    $ renpy.block_rollback()
    hide screen expedition
    hide screen pause_menu
    hide screen butterfly_obstruction
    stop music fadeout 2.0
    scene bg library_desk
    show watson closeup at watson_closeup_position
    w "I asked you to put a book in its place, Nico. Not a patron."
    scene bg library_desk
    show nico closeup at nico_closeup_position
    n "Mrs. Watson, I was trying to get the book back before—"
    scene bg library_desk
    show watson closeup at watson_closeup_position
    w "Hand me the book. Your employment has reached its due date. You're fired."
    window hide
    call screen ending_card(False, fired=True)
    return

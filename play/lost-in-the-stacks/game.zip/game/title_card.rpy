# The opening title is printed on the butterfly book itself.
transform title_arrive:
    alpha 0.0
    linear 0.7 alpha 1.0

screen title_card():
    # The software test renderer needs redraws while menus wait for input.
    if renpy.is_in_test():
        timer 0.05 repeat True action Function(renpy.restart_interaction)
    # Reuse the shelves raised 280 pixels.
    add "bg library_desk"
    add Solid("#f5efdfbb")

    fixed at title_arrive:
        xsize 1280
        ysize 720
        add "images/title_book.png":
            xalign 0.5
            ypos 0
            xysize (450, 575)
            fit "contain"
        textbutton "Begin Your Shift":
            xalign 0.5
            ypos 577
            xsize 340
            ysize 57
            background Solid("#292929")
            hover_background Solid("#454545")
            text_color "#f5efdf"
            text_hover_color "#ffffff"
            text_xalign 0.5
            text_size 32
            padding (16, 6)
            text_yalign 0.5
            action Start()
            default_focus True
        hbox:
            xalign 0.5
            ypos 646
            spacing 16
            textbutton "Instructions":
                background Solid("#292929")
                hover_background Solid("#454545")
                text_color "#f5efdf"
                text_hover_color "#ffffff"
                text_size 25
                xsize 162
                ysize 50
                padding (8, 6)
                text_xalign 0.5
                text_yalign 0.5
                action Show("instructions")
            textbutton "Credits":
                background Solid("#292929")
                hover_background Solid("#454545")
                text_color "#f5efdf"
                text_hover_color "#ffffff"
                text_size 25
                xsize 162
                ysize 50
                padding (8, 6)
                text_xalign 0.5
                text_yalign 0.5
                action Show("credits")
            textbutton "Quit":
                background Solid("#292929")
                hover_background Solid("#454545")
                text_color "#f5efdf"
                text_hover_color "#ffffff"
                text_size 25
                xsize 162
                ysize 50
                padding (8, 6)
                text_xalign 0.5
                text_yalign 0.5
                action Quit(confirm=False)

# This project uses a custom UI without gui.init(), so explicitly connect
# Ren'Py's startup/menu flow to our main_menu screen.
label main_menu:
    call screen main_menu
    return

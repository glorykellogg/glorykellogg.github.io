define config.name = "Lost in the Stacks"
define config.version = "0.1.0"
define config.window_title = "Lost in the Stacks — a library race"
define config.screen_width = 1280
define config.screen_height = 720
define config.rollback_enabled = True
define config.allow_skipping = False
define config.has_sound = True
define config.has_music = True
define config.main_menu_music = "<from 150 loop 150>audio/rite-of-spring-part-one.mp3"
define config.main_menu_music_fadein = 3.0
define config.save_directory = "LostInTheStacks-Prototype"
define config.enter_transition = None
define config.exit_transition = None
define build.name = "Lost-in-the-Stacks"

init python:
    # Keep development notes, local launchers, and test scripts out of releases.
    build.classify("**/.DS_Store", None)
    build.classify("*-PROMPT.txt", None)
    build.classify("*-PROMPTS.txt", None)
    build.classify("WATSON-GLASSES-FIX.txt", None)
    build.classify("VALIDATION.txt", None)
    build.classify("Play-on-this-Mac.command", None)
    build.classify("*.png", None)
    build.classify("game/*test*.rpy", None)
    build.classify("game/*test*.rpyc", None)
    build.classify("**.pyc", None)
    build.classify("**/__pycache__/**", None)
    build.classify("tests/**", None)
    build.classify("**.log", None)


define config.check_conflicting_properties = True
define config.game_menu_action = NullAction()

# All game audio is MP3; use browser-native playback where supported.
define config.webaudio_required_types = ["audio/mpeg"]

# Image names must match the files in game/images, including spaces and extensions.
# Fit large drawings at display time; original artwork is kept unchanged.
# Backgrounds fill the window; portraits fit inside the dialogue staging area.
image bg desk = Composite((1280, 720), (0, 0), Solid("#ffffff"), (357, 0), Transform("images/library-desk-polished.png", xysize=(566, 720), fit="contain"))
image bg library = Composite((1280, 720), (0, 0), Solid("#f5efdf"), (0, 0), Transform("images/library-polished.png", xysize=(1280, 720), fit="cover"))
# Shared title and desk-scene shelves raised by 280 pixels.
image bg library_desk = Composite((1280, 720), (0, 0), Solid("#f5efdf"), (0, -280), Transform("images/library-polished.png", xysize=(1280, 720), fit="cover"))
image bg butterfly_shelf = Transform("images/minigame-shelf.png", xysize=(1280, 720), fit="cover")
image nico neutral = Transform("images/nico-polished.png", xysize=(320, 450), fit="contain")
image watson stern = Transform("images/watson-cutout.png", xysize=(320, 450), fit="contain")
image butterfly = "images/butterfly-sprite.png"

transform portrait_left:
    xpos 100
    ypos 110

transform portrait_right:
    xpos 850
    ypos 110

transform flutter(delay=0.0):
    subpixel True
    alpha 0.0
    pause delay
    linear 0.25 alpha 1.0
    parallel:
        block:
            ease 0.22 xzoom 0.35
            ease 0.28 xzoom 1.0
            repeat
    parallel:
        block:
            ease 1.1 yoffset -22 xoffset 12 rotate 8
            ease 1.3 yoffset 8 xoffset -12 rotate -8
            repeat


# Butterfly book, redrawn from the original pencil sketch.
image book butterfly = Transform("images/butterfly_book.png", xysize=(280, 380), fit="contain")

# Trim empty canvas only at display time; source PNGs stay intact.
image desk foreground = Transform(Crop((40, 120, 1456, 790), "images/library-desk-polished.png"), xysize=(730, 477), fit="contain")
image nico at_desk = Transform(Crop((375, 115, 515, 1126), "images/nico-polished.png"), xysize=(205, 454), fit="contain")
image watson behind_desk = Transform(Crop((274, 61, 626, 1354), "images/watson-cutout.png"), xysize=(215, 465), fit="contain")
image watson closeup = Transform(Crop((320, 45, 510, 570), "images/watson-cutout.png"), xysize=(560, 626), fit="contain")
image nico closeup = Transform(Crop((415, 100, 480, 537), "images/nico-polished.png"), xysize=(560, 626), fit="contain")

transform nico_closeup_position:
    xalign 0.5
    ypos 20

transform watson_closeup_position:
    xalign 0.5
    ypos 20

transform nico_at_desk:
    xpos 125
    ypos 80

transform watson_at_desk:
    xpos 740
    ypos 60

transform desk_in_front:
    xpos 430
    ypos 300

# Book insert for Nico's opening line; separate from the title-screen art.
image bg book_closeup = Solid("#f5efdf")
image book lives = Transform("images/lives_of_butterflies.png", xysize=(400, 500), fit="contain")

transform book_closeup_position:
    xalign 0.5
    ypos 0

image bg two_way_hallway = Transform("images/library-two-way-hallway.png", xysize=(1280, 720), fit="cover")

image bg wrong_turn = Transform("images/wrong-turn.png", xysize=(1280, 720), fit="cover")

image bg three_way_hallway = Transform("images/library-three-way-hallway.png", xysize=(1280, 720), fit="cover")

# Crop transparent margins at display time so the spine fits the shelf gap.
image book shelved = Transform(Crop((368, 29, 289, 1432), "images/lives-of-butterflies-spine.png"), xysize=(88, 315), fit="contain")
transform shelved_book_position:
    xpos 770
    ypos 533
    anchor (0.5, 1.0)

# A matching filler spine, staged as sprites so all four gaps stay exactly equal.
image shelf filler = Crop((111, 356, 39, 331), "images/uniform-shelf-reference.png")

image patron waiting = Transform("images/patron.png", xysize=(430, 645), fit="contain")

image nico running_back = Transform(Crop((262, 40, 644, 1438), "images/nico-back-running.png"), xysize=(230, 510), fit="contain")

transform nico_running_motion:
    subpixel True
    anchor (0.5, 1.0)
    xpos 640
    ypos 825
    block:
        xzoom 1.0
        xoffset 0
        ease 0.14 yoffset -3 rotate -0.25
        ease 0.14 yoffset 0 rotate 0.0
        # The flowing skirt makes the sprite asymmetrical; align the torso
        # when mirroring rather than centering on the skirt's bounding box.
        xzoom -1.0
        xoffset -74
        ease 0.14 yoffset -3 rotate 0.25
        ease 0.14 yoffset 0 rotate 0.0
        repeat

init python:
    import math
    import functools

    def orbit_nico(phase, speed, trans, st, at):
        angle = st * speed + phase
        trans.xpos = int(603 + 135 * math.cos(angle))
        trans.ypos = int(470 + 100 * math.sin(angle) + 12 * math.sin(angle * 2))
        return 1.0 / 60.0

transform butterfly_around_nico(phase=0.0, speed=1.0):
    subpixel True
    anchor (0.5, 0.5)
    function functools.partial(orbit_nico, phase, speed)

transform shelf_butterfly_drift(seed=0):
    subpixel True
    parallel:
        block:
            ease (2.0 + seed * 0.12) xoffset 26
            ease (2.5 + seed * 0.1) xoffset -20
            repeat
    parallel:
        block:
            ease (1.7 + seed * 0.14) yoffset -24
            ease (2.3 + seed * 0.09) yoffset 18
            repeat

init python:
    def shelf_animation_time():
        # Screen/button interactions can reset transform-local time.
        # Keep flight and wingbeats on one persistent gameplay clock.
        extra = max(0.0, time.monotonic() - store.last_tick) if store.clock_running and not store.paused else 0.0
        return store.butterfly_flight_time + extra

    def flap_over_shelf(seed, trans, st, at):
        t = shelf_animation_time()
        trans.xzoom = 0.825 + 0.175 * math.cos(t * (6.0 + seed * 0.13) + seed * 1.7)
        return 1.0 / 60.0

    def fly_over_shelf(seed, trans, st, at):
        st = shelf_animation_time()
        # Each butterfly follows an independent, gently wandering loop.
        phase = seed * 2.39996
        direction = -1 if seed % 2 else 1
        speed = 0.65 + ((seed * 5) % 11) * 0.065
        angle = st * speed * direction + phase
        center_x = 340 + ((seed * 193) % 600)
        center_y = 270 + ((seed * 71) % 170)
        radius_x = 135 + ((seed * 47) % 105)
        radius_y = 110 + ((seed * 31) % 70)
        trans.xpos = int(center_x + radius_x * math.cos(angle) + 38 * math.sin(st * 0.37 + phase))
        trans.ypos = int(center_y + radius_y * math.sin(angle * (0.83 + seed * 0.025)) + 22 * math.cos(st * 0.53 + phase))
        trans.rotate = 10 * math.sin(angle + 0.7)
        return 1.0 / 60.0

transform shelf_butterfly_flight(seed=0):
    subpixel True
    anchor (0.5, 0.5)
    function functools.partial(fly_over_shelf, seed)

transform shelf_wingbeat(seed=0):
    subpixel True
    align (0.5, 0.5)
    function functools.partial(flap_over_shelf, seed)

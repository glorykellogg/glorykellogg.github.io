# Latin Modern Roman, distributed under the bundled GUST Font License.
# Keep the navigation arrows in Ren'Py's bundled symbol-capable font.
define game_serif = FontGroup().add("DejaVuSans.ttf", 0x2190, 0x21ff).add("fonts/lmroman10-regular.otf", 0x0000, 0x10ffff)

init python:
    config.font_replacement_map["fonts/lmroman10-regular.otf", True, False] = ("fonts/lmroman10-bold.otf", False, False)
    config.font_replacement_map["fonts/lmroman10-regular.otf", False, True] = ("fonts/lmroman10-italic.otf", False, False)
    config.font_replacement_map["fonts/lmroman10-regular.otf", True, True] = ("fonts/lmroman10-bolditalic.otf", False, False)

init python:
    def touch_size(size, scale=1.35):
        return int(round(size * scale)) if renpy.variant("touch") else size

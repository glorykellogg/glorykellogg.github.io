"""Small, engine-independent rules. Edit route text and balance here."""
TIME_LIMIT = 60.0
WRONG_TURN_COST = 20.0
WRONG_SHELF_COST = 15.0
BOOK_NUMBER = "595.789"

# Broad-to-narrow Dewey navigation; the target number stays on the book card.
STAGES = (
    dict(title="The main stacks", section="000–999", butterflies=3,
         description="Two corridors turn out of sight. The book's spine reads 595.789. Choose the half that contains the call number.",
         hint="595.789 falls in the 500–999 half of the Dewey system.",
         options=("500–999", "000–499"), correct=0),
    dict(title="The second junction", section="500–999", butterflies=3,
         description="Three butterflies flutter around your shoulders. Which range contains 595.789?",
         hint="595.789 belongs in 500–599: science.",
         options=("800–999", "600–799", "500–599"), correct=2),
    dict(title="The science wing", section="500–599", butterflies=3,
         description="A paper-white butterfly slips between the shelves. Somewhere, a clock clears its throat. Which half contains 595.789?",
         hint="595.789 falls in the upper half: 550–599.",
         options=("550–599", "500–549"), correct=0),
    dict(title="The third junction", section="550–599", butterflies=3,
         description="Three butterflies circle Nico. Find the range that contains 595.789.",
         hint="595.789 belongs in 590–599: animals.",
         options=("570–589", "590–599", "550–569"), correct=1),
    dict(title="The animal gallery", section="590–599", butterflies=3,
         description="A butterfly circles a brass sign. Its wings sound like turning pages. Which range contains 595.789?",
         hint="595.789 is between 595 and 596. Arthropods include insects.",
         options=("598 · Birds", "599 · Mammals", "595 · Arthropods"), correct=2),
    dict(title="The insect passage", section="595", butterflies=3,
         description="A butterfly hovers beside the shelves. A painted wing disappears around the corner. Follow the number beyond the decimal point.",
         hint="595.789 falls within 595.78: butterflies and moths.",
         options=("595.78 · Butterflies & moths", "595.76 · Beetles", "595.79 · Ants, bees & wasps"), correct=0),
)

SHELF_OPTIONS = (
    "Before 595.78",
    "Between 595.78 and 595.788",
    "Between 595.788 and 595.79",
    "After 595.79",
)
CORRECT_SLOT = 2

def spend_time(remaining, seconds):
    """Clamp at zero so a wrong answer can never produce a negative clock."""
    return max(0.0, remaining - max(0.0, seconds))

def clock_text(remaining):
    import math
    seconds = max(0, int(math.ceil(remaining)))
    return "{:02d}:{:02d}".format(seconds // 60, seconds % 60)


def library_clock_text(remaining):
    import math
    seconds = 18 * 3600 - max(0, int(math.ceil(remaining)))
    hour = (seconds // 3600) % 12 or 12
    return "{}:{:02d}:{:02d}".format(hour, (seconds // 60) % 60, seconds % 60)

def shuffled_stages(rng):
    """New sign positions for a shift; preserve each range's correct answer."""
    result = []
    for source in STAGES:
        order = list(range(len(source["options"])))
        rng.shuffle(order)
        node = dict(source)
        node["options"] = tuple(source["options"][i] for i in order)
        node["correct"] = order.index(source["correct"])
        result.append(node)
    return result

BUTTERFLY_BLOCK_COST = 5.0

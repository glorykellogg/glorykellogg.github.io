# Lost in the Stacks

A short, single-level race against closing time, created by Glory Kellogg for Game Design I.

You are Nico Weaver, a library employee with one book left to shelve: *The Lives of Butterflies*. Mrs. Watson expects it returned before six. Follow the Dewey signs through shifting corridors, handle an inquisitive reader, and find the right gap while butterflies get in your way.

## Run the game

This download is a **Ren’Py source project**, not a standalone application. It was developed and tested with **Ren’Py 8.5.3**.

1. Install the [Ren’Py SDK](https://www.renpy.org/).
2. Extract `Lost-in-the-Stacks.zip`. Keep the `game` folder inside `Lost-in-the-Stacks`.
3. Open the Ren’Py Launcher. In **Preferences**, set **Projects Directory** to the folder containing `Lost-in-the-Stacks`.
4. Select **Lost in the Stacks** in the launcher and choose **Launch Project**.
5. Select **Begin Your Shift**. Read the introduction, then press **Enter** on the open-book page to start the clock.

`Play-on-this-Mac.command` is a convenience shortcut for the original development computer. It uses a fully local SDK outside the cloud-managed Documents folder, and will not work by itself on another computer. Use the launcher instructions above for this source download.

## How to play

Return *The Lives of Butterflies*, call number **595.789**, before the clock reaches **6:00 PM**. A shift begins at **5:59 PM**, giving you 60 seconds. The introduction and open-book page are untimed.

- At each junction, choose the numerical range containing 595.789. There are six junctions, with either two or three routes.
- Sign positions shuffle with each new shift. They stay fixed within that shift, including when you return from a wrong turn.
- A small book in the upper-left corner keeps the call number visible.
- A Dan Brown fan interrupts halfway through the route. Choose Nico’s replies to continue the conversation.
- At the final shelf, place the book in ascending numerical order. Compare every digit after the decimal point.
- Fourteen moving butterflies obstruct the shelf. Wait for an opening before clicking; their blocking areas extend slightly beyond their visible wings.

### Controls

| Action | Control |
| --- | --- |
| Advance dialogue | Click or Enter |
| Reread dialogue | Back |
| Begin the timed shift | Enter on the open-book page |
| Choose a corridor | Left/right arrows; up arrow for the middle route, or click a sign |
| Return from a wrong corridor | Enter |
| Retry after a misplaced book | Enter or the retry button |
| Reply to the reader | Click a reply |
| Place the book | Click a shelf gap |
| Move between selectable controls | Tab / Shift+Tab, then Enter |
| Pause or resume | Escape, or the on-screen Pause/Resume button |

Saving, skipping dialogue, and rewinding the timed section are disabled. Back is available during ordinary dialogue; it cannot undo timed decisions.

### Time and mistakes

During timed play, the clock keeps advancing while you read, choose replies, or recover from mistakes. Pause stops it. Penalties advance the displayed clock toward six.

| Event | Extra time lost | Mistakes added |
| --- | ---: | ---: |
| Wrong corridor | 20 seconds | 1 |
| Wrong shelf gap | 15 seconds | 1 |
| Butterfly-blocked click | 5 seconds | 1 |
| Polite reply to the reader | 3 seconds | 0 |
| Rude reply to the reader | 15 seconds | 1 |

The conversation has three reply choices in sequence, each offering a polite or rude response. An entirely polite conversation costs nine extra seconds, plus reading and interaction time and a two-second farewell. Conversation and butterfly penalties are not printed in their dialogue boxes.

## Endings and replay

- **Success:** return the book to the correct gap before closing.
- **Timeout:** reach 6:00 PM before shelving the book.
- **Dismissal:** choose all three rude replies before the conversation is interrupted by closing time, and Mrs. Watson fires Nico.

Results show time remaining and mistakes for success, mistakes for timeout, or a dismissal message when fired. **Try another shift** returns directly to the open-book page, resets the clock and mistakes, and reshuffles the corridors. **Credits** is available on both the title and results screens.

## Credits

Game design, writing, and original drawings: **Glory Kellogg**.

Coding, dialogue development, and additional artwork assistance: **OpenAI ChatGPT / Codex and image generation**.

Music: Igor Stravinsky’s *The Rite of Spring*, Part One: *The Fertility of the Earth*. Boston Symphony Orchestra, conducted by Pierre Monteux; recorded January 28, 1951. LP transfer by Bob Varney, sourced from [Internet Archive](https://archive.org/details/the-rite-of-spring_202305).

Engine: **Ren’Py**. Typeface: **Latin Modern Roman**, with its GUST Font License included in `game/fonts`. See `CREDITS.txt` for the accompanying credit record.

## For the instructor / submission preparation

The project is one playable level using branching static scenes rather than free movement. The final shelf adds a timing challenge to the numerical navigation; the reader encounter makes conversation part of the time-management problem.

Before submitting, include the assignment’s accompanying materials:

- Representative screenshots and a short gameplay recording.
- A record of an external playtest and a brief playtest log.
- A one-page postmortem discussing what worked, what did not, and what could improve. Use the assignment’s required 12-point font, one-inch margins, and heading format.

These materials are separate from this README. For an easier download-and-play handoff, use the Ren’Py Launcher’s **Build Distributions** option and test the resulting application on the intended platform. The source ZIP is not that standalone build.

## Project maintenance

| File | Contents |
| --- | --- |
| `game/script.rpy` | Introduction, endings, and scene staging |
| `game/screens.rpy` | Interface, conversation choices, shelf puzzle, and results |
| `game/state.rpy` | Timer, penalties, conversation responses, and state changes |
| `game/python-packages/stacks_rules.py` | Dewey ranges, shuffling, time limit, and shelf answer |
| `game/assets.rpy` | Image definitions and animation |
| `game/title_card.rpy` / `game/begin_story.rpy` | Title screen and open-book start page |
| `game/credits.rpy` / `game/typography.rpy` | Credits and font setup |
| `game/images`, `game/audio`, `game/fonts` | Bundled artwork, soundtrack, and fonts |

Run **Check Script (Lint)** from the Ren’Py Launcher. The Python rules/state checks can be run from this project folder with `python3 -m unittest discover -s tests -v`. Ren’Py integration tests are included in `game/testcases.rpy`; they are development checks, not a substitute for an external playtest.

Some older preview images and art prompts remain in the source project as development records. The live game is defined by the files inside `game`.


## Website version

A Ren’Py 8.5.3 browser build is included in the personal website project at `/Users/glorykellogg/glorykellogg.github.io/play/lost-in-the-stacks/`. The homepage’s **School Projects** section links to `lost-in-the-stacks.qmd`. Run `quarto render` from that website folder to refresh `_site`, including the game resources. Publish the rendered site using the website’s usual deployment process.

The web build was checked locally for startup, opening dialogue, timed corridor navigation, pause, and the timeout sequence. Browser audio and a complete successful shelf playthrough still need a final user playtest. Desktop rule tests: 18 passing.
